/* 💬 Chat Hub Connector · background (Manifest V3)
 * ทุก 1 นาที: ใช้แท็บแชท Lazada / Shopee (ปักหมุดไว้ · เปิดให้เองถ้าไม่มี) อ่านแชทที่มีข้อความใหม่ → ส่ง "ข้อมูลดิบ" เข้า Chat Hub
 * การแปลงข้อความ (การ์ดสินค้า รูป ป้าย AI ฯลฯ) ทำที่ Chat Hub (Parse.gs) → แก้วิธีแสดงผลได้โดยไม่ต้องอัปเดตส่วนเสริม
 * อ่านอย่างเดียว: ไม่ส่งข้อความ ไม่กดอ่าน ไม่เปลี่ยนอะไรใน Lazada / Shopee
 */
const VER = chrome.runtime.getManifest().version;
const VER_URL = 'https://kengamp2555.github.io/packing-cam/chathub-ext/version.json';
const LZ_CHAT = 'https://sellercenter.lazada.co.th/apps/im/chat';
const LZ_CH = 'lazada-kengamp';
const FIRST_DAYS = 3;            // ครั้งแรก: ดึงย้อนหลังกี่วัน

const store = {
  get: k => chrome.storage.local.get(k).then(r => r[k]),
  set: (k, v) => chrome.storage.local.set({ [k]: v })
};
function ensureAlarm() { chrome.alarms.get('poll', a => { if (!a) chrome.alarms.create('poll', { periodInMinutes: 1, delayInMinutes: 0.1 }); }); }
chrome.runtime.onInstalled.addListener(() => { ensureAlarm(); chrome.runtime.openOptionsPage(); });
chrome.runtime.onStartup.addListener(ensureAlarm);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'poll') { pollAll('auto'); checkUpdate(); } });
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg && msg.cmd === 'pollNow') { pollAll('manual').then(r => reply(r)); return true; }
  if (msg && msg.cmd === 'checkUpdate') { checkUpdate(true).then(r => reply(r)); return true; }
  if (msg && msg.cmd === 'reset') { chrome.storage.local.remove(['lzState', 'spState']).then(() => reply({ ok: true })); return true; }
});
chrome.notifications.onClicked.addListener(async () => { const u = await store.get('hubUrl'); if (u) chrome.tabs.create({ url: u.split('?')[0] }); });

/* ---------- เช็กเวอร์ชันใหม่ (วันละไม่กี่ครั้ง) ---------- */
const newer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function checkUpdate(force) {
  const last = await store.get('updCheckedAt');
  if (!force && last && Date.now() - last < 6 * 3600e3) return store.get('update');
  await store.set('updCheckedAt', Date.now());
  try {
    const j = await (await fetch(VER_URL + '?t=' + Date.now(), { cache: 'no-store' })).json();
    const upd = j && j.version && newer(j.version, VER) ? { version: j.version, zip: j.zip, notes: j.notes || '' } : null;
    const prev = await store.get('update');
    await store.set('update', upd);
    if (upd && (!prev || prev.version !== upd.version)) chrome.notifications.create('upd', { type: 'basic', iconUrl: 'icon128.png', title: '🔔 Chat Hub Connector มีเวอร์ชันใหม่ ' + upd.version, message: (upd.notes || '') + ' · กดไอคอนส่วนเสริม → ดาวน์โหลด', priority: 1 });
    return upd;
  } catch (e) { return store.get('update'); }
}

let busy = false;
async function pollAll(why) {
  if (busy) return { ok: false, msg: 'กำลังทำงานอยู่' };
  busy = true;
  const st = { at: Date.now(), why };
  try {
    const url = await store.get('hubUrl');
    if (!url) throw new Error('ยังไม่ได้ตั้งลิงก์ Chat Hub (กดไอคอน → ตั้งค่า)');
    if ((await store.get('lzOn')) !== false) { try { st.lazada = await pollLazada(url); } catch (e) { st.lazada = { error: String(e && e.message || e) }; } }
    if ((await store.get('spOn')) !== false) { try { st.shopee = await pollShopee(url); } catch (e) { st.shopee = { error: String(e && e.message || e) }; } }
    st.ok = true;
  } catch (e) { st.ok = false; st.error = String(e && e.message || e); }
  finally { busy = false; }
  await store.set('lastRun', st);
  badge(st);
  return st;
}
function badge(st) {
  const err = !st.ok || (st.lazada && st.lazada.error) || (st.shopee && st.shopee.error);
  const n = ((st.lazada && st.lazada.newIn) || 0) + ((st.shopee && st.shopee.newIn) || 0);
  chrome.action.setBadgeBackgroundColor({ color: err ? '#d93025' : '#1a73e8' });
  chrome.action.setBadgeText({ text: err ? '!' : (n ? String(n) : '') });
}

/* ---------- Lazada ---------- */
async function lazadaTab() {
  const tabs = await chrome.tabs.query({ url: 'https://sellercenter.lazada.co.th/*' });
  let t = tabs.find(x => /\/apps\/im\//.test(x.url || '')) || tabs[0];
  if (!t) {
    t = await chrome.tabs.create({ url: LZ_CHAT, active: false, pinned: true });
    await waitComplete(t.id);
  }
  try { await chrome.tabs.update(t.id, { autoDiscardable: false }); } catch (e) { }
  if (t.discarded) { await chrome.tabs.reload(t.id); await waitComplete(t.id); }
  return t;
}
function waitComplete(id) {
  return new Promise(res => {
    const done = () => { chrome.tabs.onUpdated.removeListener(f); clearTimeout(h); setTimeout(res, 1500); };
    const f = (tid, info) => { if (tid === id && info.status === 'complete') done(); };
    const h = setTimeout(done, 30000);
    chrome.tabs.onUpdated.addListener(f);
  });
}
async function pollLazada(hubUrl) {
  const state = (await store.get('lzState')) || { since: Date.now() - FIRST_DAYS * 864e5, seen: {} };
  const tab = await lazadaTab();
  const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: lzPollInPage, args: [state] });
  const r = res && res.result;
  if (!r) return { error: 'อ่านหน้า Lazada ไม่ได้' };
  if (r.error) {
    if (r.error === 'login') await notifyOnce('lzlogin', 'Lazada Seller Center ออกจากระบบแล้ว', 'เปิดแท็บ Lazada ที่ปักหมุดไว้ แล้วล็อกอินใหม่');
    return { error: r.error === 'login' ? 'ต้องล็อกอิน Lazada ใหม่' : r.error };
  }
  const fresh = await sendHub(hubUrl, LZ_CH, 'lazada', {}, r.items);
  await store.set('lzState', { since: state.since, seen: r.seen });
  if (fresh.length && state.seen && Object.keys(state.seen).length) notifyNew('Lazada', fresh);   // ไม่เด้งตอนดึงครั้งแรก
  return { sessions: r.checked, items: r.items.length, newIn: fresh.length };
}
/* ---------- Shopee (Seller Centre แชท · ร้านที่ล็อกอินอยู่ในเบราว์เซอร์นี้) ---------- */
const SP_CHAT = 'https://seller.shopee.co.th/new-webchat/conversations';
const SP_CH = { kengann9: 'shopee-kengann9', keng77: 'shopee-keng77' };   // ชื่อผู้ใช้ร้าน → ช่องทางใน Chat Hub
async function shopeeTab() {
  const tabs = await chrome.tabs.query({ url: 'https://seller.shopee.co.th/*' });
  let t = tabs.find(x => /webchat/.test(x.url || '')) || tabs[0];
  if (!t) { t = await chrome.tabs.create({ url: SP_CHAT, active: false, pinned: true }); await waitComplete(t.id); }
  try { await chrome.tabs.update(t.id, { autoDiscardable: false }); } catch (e) { }
  if (t.discarded) { await chrome.tabs.reload(t.id); await waitComplete(t.id); }
  return t;
}
async function pollShopee(hubUrl) {
  const all = (await store.get('spState')) || {};
  const tab = await shopeeTab();
  const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: spPollInPage, args: [all] });
  const r = res && res.result;
  if (!r) return { error: 'อ่านหน้า Shopee ไม่ได้' };
  if (r.error) {
    if (r.error === 'login') await notifyOnce('splogin', 'Shopee Seller Centre ออกจากระบบแล้ว', 'เปิดแท็บ Shopee ที่ปักหมุดไว้ แล้วล็อกอินใหม่');
    return { error: r.error === 'login' ? 'ต้องล็อกอิน Shopee ใหม่ (เปิดหน้าแชทใน Seller Centre)' : r.error };
  }
  const ch = SP_CH[String(r.user || '').toLowerCase()];
  if (!ch) return { error: 'ร้าน Shopee "' + r.user + '" ยังไม่มีใน Chat Hub' };
  const fresh = await sendHub(hubUrl, ch, 'shopee', { shopId: r.shopId }, r.items);
  const first = !all[r.user];
  all[r.user] = { since: r.since, seen: r.seen };
  await store.set('spState', all);
  if (fresh.length && !first) notifyNew('Shopee ' + r.user, fresh);
  return { shop: r.user, sessions: r.checked, items: r.items.length, newIn: fresh.length };
}
/** ส่งข้อมูลดิบเข้า Chat Hub ทีละ 40 ข้อความ · คืนรายการข้อความลูกค้าที่เพิ่งเข้าใหม่ (Chat Hub เป็นคนบอก) */
async function sendHub(hubUrl, ch, src, ctx, items) {
  const fresh = [];
  for (let i = 0; i < items.length; i += 40) {
    const resp = await fetch(hubUrl, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ ch, src, ctx, ver: VER, items: items.slice(i, i + 40) }) });
    let j = null; try { j = await resp.json(); } catch (e) { }
    if (!j || !j.ok) throw new Error('Chat Hub ไม่รับข้อมูล' + (j && j.error ? ' (' + j.error + ')' : ' – ตรวจลิงก์ในตั้งค่า'));
    (j.fresh || []).forEach(x => fresh.push(x));
  }
  return fresh;
}
function notifyNew(label, newIn) {
  const by = {}; newIn.forEach(m => { by[m.name] = m.text; });
  const names = Object.keys(by);
  chrome.notifications.create('n' + Date.now(), { type: 'basic', iconUrl: 'icon128.png', title: '💬 ' + label + ' · ' + names.slice(0, 2).join(', ') + (names.length > 2 ? ' +' + (names.length - 2) : ''), message: String(by[names[0]] || '').slice(0, 120), priority: 1 });
}
/* รันในหน้า Seller Centre (world: MAIN) · ใช้ session แชทของหน้าเว็บเอง · อ่านอย่างเดียว */
async function spPollInPage(all) {
  let ses = null;
  for (let i = 0; i < 20; i++) { try { ses = JSON.parse(localStorage.getItem('chat-session') || 'null'); } catch (e) { } if (ses && ses.token) break; await new Promise(r => setTimeout(r, 500)); }
  if (!ses || !ses.token || !ses.user) return { error: 'login' };
  const user = String(ses.user.name || ''), state = all[user] || { since: Date.now() - 3 * 864e5, seen: {} };
  const ck = Object.fromEntries(document.cookie.split('; ').map(c => { const i = c.indexOf('='); return [c.slice(0, i), c.slice(i + 1)]; }));
  const tail = '_uid=' + ses.user.uid + '&_v=9.1.17&csrf_token=&SPC_CDS_CHAT=' + (ck.SPC_CDS_CHAT || '') + '&x-shop-region=TH&_api_source=webchat';
  const get = async p => {
    const r = await fetch('/webchat/api/' + p + (p.includes('?') ? '&' : '?') + tail, { credentials: 'include', headers: { Authorization: 'Bearer ' + ses.token } });
    if (r.status === 401 || r.status === 403) throw new Error('login');
    if (!r.ok) throw new Error('Shopee ตอบ ' + r.status);
    return r.json();
  };
  let convs;
  try { convs = await get('v1.2/conversations?direction=older&type=all&limit=30&biz_id=0'); }
  catch (e) { return { error: e.message === 'login' ? 'login' : e.message }; }
  const shopId = String(ses.shop && ses.shop.id || ''), seen = Object.assign({}, state.seen || {}), items = [];
  /* ตัดส่วนที่ไม่ใช้ (คำแปลหลายภาษา ข้อมูลติดตาม) ให้ข้อมูลดิบเล็กลง · ที่เหลือส่งทั้งก้อนให้ Chat Hub แปลงเอง */
  const DROP = /^(translated_text|buyer_translated_text|translated_with_lang|translated_text_list|noti_text_of_all_languages|follow_up_question|tracking_play_load|msg_tag|msg_attr|crm_activity_id|warning|waring_tip_types|feedback_info|request_id|region|country|model_price_info|selling_point|review_bar|edt|image_overlays_hash|pass_through_data)$/;
  const slim = (v, d) => {
    if (d > 8 || v == null) return v;
    if (Array.isArray(v)) return v.slice(0, 8).map(x => slim(x, d + 1));
    if (typeof v === 'object') { const o = {}; Object.keys(v).forEach(k => { if (!DROP.test(k)) o[k] = slim(v[k], d + 1); }); return o; }
    return typeof v === 'string' && v.length > 4000 ? v.slice(0, 4000) : v;
  };
  let checked = 0;
  for (const c of convs || []) {
    const last = Date.parse(c.last_message_time) || 0, prev = Number(seen[c.id] || state.since || 0);
    if (!c.id || last <= prev) continue;
    checked++;
    try {
      const M = await get('v1.2/conversations/' + c.id + '/messages?shop_id=' + shopId + '&offset=0&limit=20&direction=older&biz_id=0&on_message_received=true');
      (M || []).forEach(m => {
        const at = Date.parse(m.created_at) || (Number(m.created_timestamp) * 1000) || 0;
        if (!m.id || at <= prev) return;
        items.push({ uid: String(c.id), name: c.to_name || '', pic: c.to_avatar || '', at, msgId: String(m.id), raw: slim(m, 0) });
      });
      seen[c.id] = last;
    } catch (e) { if (e.message === 'login') return { error: 'login' }; }
    await new Promise(r => setTimeout(r, 300));
  }
  items.sort((a, b) => a.at - b.at);
  return { user, shopId, since: state.since, seen, items, checked };
}

async function notifyOnce(key, title, message) {
  const k = 'notified_' + key, last = await store.get(k);
  if (last && Date.now() - last < 3 * 3600e3) return;
  await store.set(k, Date.now());
  chrome.notifications.create(key, { type: 'basic', iconUrl: 'icon128.png', title, message, priority: 2 });
}

/* รันในหน้า Lazada (world: MAIN) · ใช้ lib.mtop ของหน้าเว็บเอง · อ่านอย่างเดียว */
async function lzPollInPage(state) {
  for (let i = 0; i < 30 && !(window.lib && window.lib.mtop); i++) await new Promise(r => setTimeout(r, 500));
  if (!(window.lib && window.lib.mtop)) return { error: /login/.test(location.href) ? 'login' : 'หน้า Lazada ยังโหลดไม่เสร็จ' };
  if (/\/login/.test(location.pathname)) return { error: 'login' };
  const req = (api, data) => window.lib.mtop.request({ v: '1.0', appKey: '4272', timeout: 30000, H5Request: true, type: 'GET', method: 'GET', api, url: api,
    data, dataType: 'json', valueType: 'original', 'x-i18n-regionID': 'LAZADA_TH' });
  const base = { accessKey: 'lazada-pc-h5', accessToken: 'lazada-test-secret', accountType: 2, nodeId: 1 };
  let sres;
  try { sres = await req('mtop.im.use.web.seller.messagebox.querySessionList', Object.assign({ startTime: String(Date.now()), fetchCount: 30, pageNum: 1 }, base)); }
  catch (e) { const ret = JSON.stringify((e && e.ret) || e || ''); return { error: /SESSION|LOGIN|TOKEN_EXOIRED|FAIL_SYS_SESSION/i.test(ret) ? 'login' : 'Lazada ตอบผิดพลาด: ' + ret.slice(0, 120) }; }
  const sessions = (sres && sres.data && sres.data.sessionViewDTOList) || [];
  const seen = Object.assign({}, state.seen || {}), items = [];
  const at = m => Number(((m.body || {}).typeData || {}).sendTime) || 0;
  const mid = m => { const t = (m.body || {}).typeData || {}; return t.mid || t.bizUnique || ''; };
  let checked = 0;
  for (const sv of sessions) {
    const sd = sv.sessionData || {}, last = Number(sd.lastMessageTime || 0), prev = Number(seen[sv.sessionId] || state.since || 0);
    if (!sv.sessionId || last <= prev) continue;
    checked++;
    try {
      const r = await req('mtop.im.use.seller.messagebox.queryMessageListBySessionId', Object.assign({ sessionViewId: sv.sessionId, startTime: String(Date.now()), fetchCount: 20, isDownward: false }, base));
      ((r.data && r.data.result) || []).filter(m => mid(m) && at(m) > prev)
        .forEach(m => items.push({ uid: sv.sessionId, name: sd.title || '', pic: sd.headUrl || '', at: at(m), msgId: String(mid(m)), raw: m }));
      seen[sv.sessionId] = last;
    } catch (e) { /* แชทนี้ลองใหม่รอบหน้า */ }
    await new Promise(r => setTimeout(r, 400));
  }
  items.sort((a, b) => a.at - b.at);
  return { items, seen, checked };
}
