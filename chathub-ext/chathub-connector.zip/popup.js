const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function show(st, hub) {
  if (!hub) { $('st').innerHTML = '<span class="err">⚠️ ยังไม่ได้ตั้งลิงก์ Chat Hub</span> – กด ⚙ ตั้งค่า'; return; }
  if (!st) { $('st').textContent = 'ยังไม่เคยทำงาน – กด ↻ ดึงแชทตอนนี้'; return; }
  const lz = st.lazada || {};
  $('st').innerHTML = 'รอบล่าสุด: ' + new Date(st.at).toLocaleTimeString('th-TH') + ' (' + (st.why === 'manual' ? 'กดเอง' : 'อัตโนมัติทุก 1 นาที') + ')<br>' +
    (st.ok ? '' : '<span class="err">❌ ' + esc(st.error) + '</span><br>') +
    '<b>Lazada:</b> ' + (lz.error ? '<span class="err">❌ ' + esc(lz.error) + '</span>' : st.ok ? '<span class="ok">✅ ตรวจ ' + (lz.sessions || 0) + ' แชท · ส่งเข้า ' + (lz.items || 0) + ' ข้อความ</span>' : '-') +
    '<br><b>LINE OA:</b> ' + (function(ln) { return !ln ? '-' : ln.error ? '<span class="err">❌ ' + esc(ln.error) + '</span>' : '<span class="ok">✅ ' + esc(ln.bots) + ' · ส่งเข้า ' + (ln.items || 0) + ' ข้อความ</span>'; })(st.line) +
    '<br><b>Shopee:</b> ' + (function(sp) { return !sp ? '-' : sp.error ? '<span class="err">❌ ' + esc(sp.error) + '</span>' : '<span class="ok">✅ ' + esc(sp.shop) + ' · ตรวจ ' + (sp.sessions || 0) + ' แชท · ส่งเข้า ' + (sp.items || 0) + ' ข้อความ</span>'; })(st.shopee);
}
async function load() { const r = await chrome.storage.local.get(['lastRun', 'hubUrl']); show(r.lastRun, r.hubUrl); return r; }
load();
$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
chrome.runtime.sendMessage({ cmd: 'checkUpdate' }).then(u => {
  if (!u || !u.version) return;
  $('upd').hidden = false;
  $('upd').innerHTML = '🔔 <b>มีเวอร์ชันใหม่ ' + esc(u.version) + '</b>' + (u.notes ? '<br>' + esc(u.notes) : '') +
    '<br>① ดาวน์โหลด → แตก zip ทับโฟลเดอร์เดิม<br>② chrome://extensions → กด 🔄 ที่ส่วนเสริมนี้' +
    '<a class="dl" target="_blank" href="' + esc(u.zip) + '">⬇ ดาวน์โหลด</a>';
});
$('now').onclick = async () => { $('now').disabled = true; $('now').textContent = '⏳ กำลังดึง…'; const st = await chrome.runtime.sendMessage({ cmd: 'pollNow' }); const r = await chrome.storage.local.get('hubUrl'); show(st, r.hubUrl); $('now').disabled = false; $('now').textContent = '↻ ดึงแชทตอนนี้'; };
function showJobs(j, on) {
  if (on === false) { $('jobs').innerHTML = 'ปิดอยู่ (เปิดได้ใน ⚙ ตั้งค่า)'; return; }
  if (!j) { $('jobs').innerHTML = 'ยังไม่เคยทำงาน – กด 🟢 เช็กงานเบื้องหลังตอนนี้'; return; }
  const ic = { ok: '✅', run: '⏳', warn: '⚠️', wait: '🟡', skip: '⚪' };
  $('jobs').innerHTML = 'รอบล่าสุด ' + new Date(j.at).toLocaleTimeString('th-TH') + (j.error ? '<br><span class="err">❌ ' + esc(j.error) + '</span>' : '') +
    (j.items || []).map(x => '<br>' + (ic[x.state] || '') + ' ' + esc(x.label) + ' <span style="color:#6b7685">· ' + esc(x.note) + '</span>').join('');
}
chrome.storage.local.get(['jobsLast', 'jobsOn']).then(r => showJobs(r.jobsLast, r.jobsOn));
$('jobsNow').onclick = async () => { $('jobsNow').disabled = true; const r = await chrome.runtime.sendMessage({ cmd: 'runJobs' }); showJobs(r, true); $('jobsNow').disabled = false; };
$('catNow').onclick = async () => { const b = $('catNow'); b.disabled = true; b.textContent = '⏳ กำลังอ่านรายการสินค้า (1–2 นาที)…'; const r = await chrome.runtime.sendMessage({ cmd: 'catalogNow' }); b.textContent = '📦 ' + (r && r.res ? Object.values(r.res).join(' · ') : 'เสร็จ'); b.disabled = false; };
$('hub').onclick = async () => { const r = await load(); if (r.hubUrl) chrome.tabs.create({ url: r.hubUrl.split('?')[0] }); };
$('opt').onclick = () => chrome.runtime.openOptionsPage();
